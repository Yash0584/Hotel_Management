<?php
// Process the form data only if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $card_number = htmlspecialchars($_POST['card_number']);
    $expiry_date = htmlspecialchars($_POST['expiry_date']);
    $cvv = htmlspecialchars($_POST['cvv']);
    $cardholder_name = htmlspecialchars($_POST['cardholder_name']);

    // Define booking details (can be retrieved from a session, database, or form)
    $room_type = "Deluxe Room";
    $num_nights = 3;
    $amount_per_night = 5000; // Amount per night in rupees
    $total_amount = $amount_per_night * $num_nights;

    // Apply discount (10%)
    $discount = 0.10; // 10% discount
    $discount_amount = $total_amount * $discount;
    $discounted_amount = $total_amount - $discount_amount;

    // Apply tax (18%)
    $tax = 0.18; // 18% tax
    $tax_amount = $discounted_amount * $tax;
    $final_amount = $discounted_amount + $tax_amount;

    // Display the payment details
    echo "<h1>Payment Details</h1>";
    echo "<p><strong>Card Number:</strong> " . $card_number . "</p>";
    echo "<p><strong>Expiry Date:</strong> " . $expiry_date . "</p>";
    echo "<p><strong>CVV:</strong> " . $cvv . "</p>";
    echo "<p><strong>Cardholder Name:</strong> " . $cardholder_name . "</p>";

    // Display booking details and payment amount
    echo "<h2>Booking Details</h2>";
    echo "<p><strong>Room Type:</strong> " . $room_type . "</p>";
    echo "<p><strong>Number of Nights:</strong> " . $num_nights . "</p>";
    echo "<p><strong>Amount (Per Night):</strong> ₹" . $amount_per_night . "</p>";
    echo "<p><strong>Total Amount:</strong> ₹" . $total_amount . "</p>";

    // Display discount and tax details
    echo "<p><strong>Discount Applied (10%):</strong> ₹" . $discount_amount . "</p>";
    echo "<p><strong>Discounted Amount:</strong> ₹" . $discounted_amount . "</p>";
    echo "<p><strong>Tax (18%):</strong> ₹" . $tax_amount . "</p>";

    // Display final payment amount
    echo "<h3><strong>Final Payment Amount:</strong> ₹" . number_format($final_amount, 2) . "</h3>";
} else {
    // If the form wasn't submitted correctly, redirect back to the form page
    header("Location: payment.html");
    exit();
}
?>
